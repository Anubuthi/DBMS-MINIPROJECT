import streamlit as st
import pandas as pd
import datetime
from database import add_data_rocket, add_data_payload, add_data_droneship, add_data_launchpad,add_data_admin,view_all_data,add_data_launch,add_data_mission



def create_rocket():
    col1, col2 = st.columns(2)
    with col1:
        rocket_id = st.text_input("Rocket id:")
        rocket_name = st.text_input("Rocket Name:")
        rocket_type = st.selectbox("Type", ["Rocket", "Drone", "cargo","high speed craft"])
    with col2:
        active = st.selectbox("STATUS", ["True","False"])
        country = st.text_input("country:")
        company = st.text_input("company:")
        cost_per_launch = st.number_input('Select cost of the launch :')

    if st.button("Add Rocket"):
        add_data_rocket(rocket_id, rocket_name, rocket_type, active,country, company, cost_per_launch)
        st.success('Successfully added rocket: "{}"'.format(rocket_name))

def create_payload():
    col1, col2 = st.columns(2)
    with col1:
        payload_id = st.text_input("payload id:")
        name = st.text_input("Payload  Name:")
        type = st.selectbox("Type", ["Satellite", "Dragon1.0", "Dragon1.1","Lander","crew Dragon"])
        reuse = st.radio("reuse",["True", "False"])
        manufacture=st.text_input("Manufctured by :")
        mass_kg=st.number_input("mass of the payload in kg:")
        mass_lb=2.025 * mass_kg


    with col2:
        st.subheader("orbital information")
        orbit = st.selectbox("ORBIT", ["LEO", "ISS", "PO","GTO","ES-L1","SSO","HE0","MEO","VLEO"])
        reference_system= st.selectbox("Reference system", ["geocentric", "heliocentric", "highly-elliptical"])
        regime = st.selectbox("regime",["low-earth","geostationary","L1-point","geosynchronous","sun-synchronous","high-earth","semi-synchronous","highly-elliptical","very-low-earth"])

    if st.button("Add Payload"):
        add_data_payload(payload_id, name, type, reuse, manufacture, mass_kg,mass_lb,orbit,reference_system,regime)
        st.success('Successfully added Payload: "{}"'.format(name))


def create_launchpad():
    col1, col2 = st.columns(2)
    with col1:
        launchpad_id = st.text_input("Launchpad id:")
        name = st.text_input("Name:")
        full_name = st.text_input("Full Name:")
        status = st.selectbox("Status",["retired","active","under construction"])
    with col2:
        locality = st.text_input("Locality:")
        region = st.text_input("Region:")
        TimeZone =st.text_input("Time Zone:")
        Latitude=st.number_input("Latitude :")
        Longitude=st.number_input("Longitude: ")
 
    if st.button("Add Launch Pad"):
        add_data_launchpad(launchpad_id,name,full_name,status,locality,region,TimeZone , Latitude , Longitude)
        st.success('Successfully added Launch Pad: "{}"'.format(name))

def create_droneship():
    col1, col2 = st.columns(2)
    with col1:
        ship_id = st.text_input("Ship id:")
        home_port = st.text_input("home port:")
        name = st.text_input("name :")
    with col2:
        type = st.selectbox("Type", ["Tug", "High Speed Craft", "Crago"])
        roles = st.selectbox("Roles", ["Support Ship", "Fairing Recovery", "ASDS Tug"])
        activity = st.radio("Activity",["True", "False"])
        mass_kg=st.number_input("Mass in kg :")
        mass_lb= mass_kg*2.025

    if st.button("Add Drone"):
        add_data_droneship(ship_id,home_port,name,type,roles,activity,mass_kg,mass_lb)
        st.success('Successfully added Drone: "{}"'.format(name))

def create_admin():
    col1, col2 = st.columns(2)
    with col1:
        admin_id = st.text_input("Admin id:")
        name = st.text_input("Admin name:")
        st.write("Enter 12 digit password")
        password = st.text_input("passsword:")
    with col2:
        access_level = st.selectbox("Access Level", ["root","standard"])


    if st.button("Add Admin"):
        add_data_admin(admin_id, name,password, access_level)
        st.success('Successfully added Admin: "{}"'.format(name))


def create_launch():
    col1,col2=st.columns(2)
    with col1:
        result1 = view_all_data('rockets')
        df = pd.DataFrame(result1, columns=['rocket_id', 'name', 'type', 'active', 'country','company', 'cost_per_launch'])
        list_of_rockets = [i for i in df['rocket_id']]
        selected_rocket = st.selectbox("choose the rocket id of rocket to add to launch", list_of_rockets)

        result2 = view_all_data('launchpads')
        df = pd.DataFrame(result2, columns=['launchpad_id','name','full_name','status','locality','region','TimeZone' , 'Latitude' , 'Longitude'])
        list_of_launchpads = [i for i in df['launchpad_id']]
        selected_launchpad = st.selectbox("choose the launchpadid for the launchpad to launch the rocket", list_of_launchpads)


    with col2:
        status = st.radio("Status",["True", "False"])
        name = st.text_input("Name:")
    
    if st.button("Add Launch"):
        add_data_launch(selected_launchpad,selected_rocket,name,status)
        st.success('Successfully added launch: "{}"'.format(name))


def create_mission():
    col1,col2=st.columns(2)
    with col1:
        result1 = view_all_data('rockets')
        df = pd.DataFrame(result1, columns=['rocket_id', 'name', 'type', 'active', 'country','company', 'cost_per_launch'])
        list_of_rockets = [i for i in df['rocket_id']]
        selected_rocket = st.selectbox("choose the rocket id of rocket to add to mission", list_of_rockets)

        result2 = view_all_data('launchpads')
        df = pd.DataFrame(result2, columns=['launchpad_id','name','full_name','status','locality','region','TimeZone' , 'Latitude' , 'Longitude'])
        list_of_launchpads = [i for i in df['launchpad_id']]
        selected_launchpad = st.selectbox("choose the launchpadid for the launchpad to launch the rocket for mission", list_of_launchpads)

        result = view_all_data('payloads')
        df = pd.DataFrame(result, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
        list_of_payload = [i for i in df['payload_id']]
        selected_payload = st.selectbox("choose the payload id of the payload to add to mission ", list_of_payload)

        



    with col2:
        launch_status = st.radio("Status",["True", "False"])
        name = st.text_input("Launch name:")
        launch_id = st.text_input("Launch id:")
        date=st.date_input("Date of launch:")
        time=st.time_input("Time of launch:")
    my_datetime= str(date)+str(time)
    
    if st.button("Add Launch"):
        add_data_mission(my_datetime,selected_launchpad,selected_rocket,selected_payload,launch_id,name,launch_status)
        st.success('Successfully added launch: "{}"'.format(name))





    



