import streamlit as st
from PIL import Image


from create import create_admin,create_droneship,create_launchpad,create_payload,create_rocket,create_launch,create_mission
from delete import delete_admin,delete_droneship,delete_mission,delete_payload,delete_rocket
from read import read_admin,read_droneship,read_launchpad,read_mission,read_payload,read_rocket,read_launch
from update import update_admin,update_mission,update_payload,update_rocket
from sql import sql
import pickle
from pathlib import Path
import streamlit_authenticator as stauth

st.title("SPACEX")
st.title("DATABASE MANAGEMENT SYSTEM")
image = Image.open('rocket.jpg')
st.image(image, caption='SPACEX')

# USER authentication

names = ["Anubuthi","Niveditha"]
usernames = ["anu14","nkund17"]

file_path = Path(__file__).parent/"hashed_pwd.pkl"

with file_path.open("rb") as file:
    hashed_pwds = pickle.load(file)

credentials = {"usernames":{}}

for un, name, pw in zip(usernames, names, hashed_pwds):
    user_dict = {"name":name,"password":pw}
    credentials["usernames"].update({un:user_dict})

authenticator = stauth.Authenticate(credentials, "spacexdb", "auth", cookie_expiry_days=30)

name,authentication_status,username = authenticator.login("Login","main")

if authentication_status == False:
    st.error("Username/password is incorrect")

if authentication_status == None:
    st.warning("Please enter your username and password")

if authentication_status:
    authenticator.logout("Logout","sidebar")
    st.sidebar.title(f"Welcome {name}")
    menu = ["Rockets","Payloads","Missions","Launchpads","Droneships","Administrators","Launches","About SpaceXDB","SQL QUERY"]
    choice = st.sidebar.selectbox("Tables", menu)

    if choice == "Rockets":
        #create_table("CREATE TABLE Rockets (rocket_id VARCHAR(24) NOT NULL PRIMARY KEY,name VARCHAR(20),type VARCHAR(10),active VARCHAR(10),country VARCHAR(40),company VARCHAR(20), cost_per_launch INTEGER);")
        menu = ["Add Rocket","View Rockets","Edit Rocket Info","Remove Rocket","About Rocket"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Rocket':
            st.subheader("Provide Rocket Details:")
            create_rocket()
        elif choice=='View Rockets':
            st.subheader("View Rocket Details:")
            read_rocket()
        elif choice=='Edit Rocket Info':
            st.subheader("Edit Rocket Details:")
            update_rocket()
        elif choice=='Remove Rocket':
            st.subheader("Remove Rocket:")
            delete_rocket()
        else:
            st.subheader("About Rocket")
            st.write("SpaceX was formed by entrepreneur Elon Musk in the hopes of revolutionizing the aerospace industry and making affordable spaceflight a reality. The company entered the arena with the Falcon 1 rocket, a two-stage liquid-fueled craft designed to send small satellites into orbit")


    elif choice == "Payloads":
        #create_table("CREATE TABLE Payloads(payload_id VARCHAR(24) NOT NULL PRIMARY KEY,name VARCHAR(35), type VARCHAR(20), reuse VARCHAR(10), manufacture VARCHAR(40), mass_kg FLOAT, mass_lb FLOAT, orbit VARCHAR(10), reference_system VARCHAR(30),regime VARCHAR(30));")
    
        menu = ["Add Payload","View Payloads","Edit Payload Info","Remove Payload","About Payload"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Payload':
            st.subheader("Provide Payload Details:")
            create_payload()
        elif choice=='View Payloads':
            st.subheader("View Payload Details:")
            read_payload()
        elif choice=='Edit Payload Info':
            st.subheader("Edited Payload Details:")
            update_payload()
        elif choice=='Remove Payload':
            st.subheader("Delete Payload:")
            delete_payload()
        else:
            st.subheader("About Payload")
            st.write("For a rocket, the payload can be a satellite, space probe, or spacecraft carrying humans, animals, or cargo")

    elif choice == "Missions":
            #create_table("CREATE TABLE Missions (date DATETIME, name VARCHAR(50), rocket_id VARCHAR(24),launchpad_id VARCHAR(24), launch_id VARCHAR(24) NOT NULL PRIMARY KEY, payload_id VARCHAR(24) ,FOREIGN KEY (rocket_id) REFERENCES Rockets(rocket_id), FOREIGN KEY (launchpad_id) REFERENCES LaunchPads(launchpad_id), FOREIGN KEY (payload_id) REFERENCES Payloads(payload_id), launch_status VARCHAR(10));")
            
            menu = ["Add Missions","View Missions","Edit Mission Info","Remove Mission","About Mission"]
            choice = st.sidebar.selectbox("Actions",menu)

            if choice=='Add Missions':
                st.subheader("Add Mission Details:")
                create_mission()
            elif choice=='View Missions':
                st.subheader("View Mission Details:")
                read_mission()
            elif choice=='Edit Mission Info':
                st.subheader("Edited Mission Details:")
                update_mission()
            elif choice=='Remove Mission':
                st.subheader("Delete Mission:")
                delete_mission()
            else:
                st.subheader("About Mission")
                st.subheader("CURRENT MISSION:")
                st.write("To Mars and back Together the Starship spacecraft and Super Heavy rocket create a reusable transportation system capable of on orbit refueling and leveraging Mars' natural H2O and CO2 resources to refuel on the surface of Mars. Starship launches with Starship Super Heavy booster. Booster separates, returning to Earth.")

    elif choice == "Launchpads":
        #create_table("CREATE TABLE LaunchPads (launchpad_id VARCHAR(24) NOT NULL PRIMARY KEY,name VARCHAR(50),full_name VARCHAR(80),status VARCHAR(30),locality VARCHAR(50),region VARCHAR(30),TimeZone VARCHAR(40),Latitude FLOAT, Longitude FLOAT);")
        
        menu = ["Add Launchpad","View Launchpads","About Launchpad"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Launchpad':
            st.subheader("Provide Launchpad Details:")
            create_launchpad()
        elif choice=='View Launchpads':
            st.subheader("View Launchpad Details:")
            read_launchpad()
        else:
            st.subheader("About Launchpad")
            st.write("A launch pad is the area and facilities where rockets or spacecrafts liftoff. A Spaceport (or rocket launch site) can contain one or many launch pads. A typical launch pad consists of the service and umbilical structures. The service structure provides an access platform to inspect the launch vehicle prior to launch.")

    elif choice == "Droneships":
        #create_table("CREATE TABLE DroneShip(ship_id VARCHAR(24) NOT NULL PRIMARY KEY,home_port VARCHAR(30),name VARCHAR(35),type VARCHAR(20),roles VARCHAR(45),activity VARCHAR(10),mass_kg FLOAT,mass_lb FLOAT);")

        menu = ["Add Droneship","View Droneships","Remove Droneship","About Droneship"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Droneship':
            st.subheader("Provide Droneship Details:")
            create_droneship()
        elif choice=='View Droneships':
            st.subheader("View Droneship Details:")
            read_droneship()
        elif choice=='Remove Droneship':
            st.subheader("Delete Droneship:")
            delete_droneship()
        else:
            st.subheader("About Droneship")
            st.write("LATEST NEWS")
            st.write("https://www.space.com/spacex-new-drone-ship-returns-1st-rocket-landing-photos")
        
    elif choice == "Administrators":
        #create_table("CREATE TABLE Administrators (admin_id VARCHAR(12) NOT NULL PRIMARY KEY, name VARCHAR(25),password VARCHAR(20) CHECK ( LENGTH(password) > 8 ), access_level VARCHAR(10));")

        menu = ["Add Admin","View Admins","Edit Admin Info","Remove Admin"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Admin':
            st.subheader("Provide Admin Details:")
            create_admin()
        elif choice=='View Admins':
            st.subheader("View Admin Details:")
            read_admin()
        elif choice=='Edit Admin Info':
            st.subheader("Edited Admin Details:")
            update_admin()
        elif choice=='Remove Admin':
            st.subheader("Delete Admin:")
            delete_admin()

    elif choice=="Launches":
        menu = ["Add Launches","View Launches"]
        choice = st.sidebar.selectbox("Actions",menu)
        if choice=='Add Launches':
            st.subheader("Provide Launch Details:")
            create_launch()
        elif choice=='View Launches':
            st.subheader("View Launch Details:")
            read_launch()


    elif choice=="SQL QUERY":
        st.subheader("SQL QUERIES")
        data=sql()
        st.dataframe(data)


    else:
        st.subheader("About SpaceXDB")
        st.write("Space Exploration Technologies Corp. is an American spacecraft manufacturer, launcher, and a satellite communications corporation headquartered in Hawthorne, California. It was founded in 2002 by Elon Musk with the stated goal of reducing space transportation costs to enable the colonization of Mars")
        image2 = Image.open('logo.jpg')
        st.image(image2)
        st.write("FACLON 9 BLOCK 5 ROCKET")
        image1 = Image.open('rocket11.jpg')
        st.image(image1)






    

