import pickle 
from pathlib import Path


import streamlit_authenticator as stauth

names = ["Anubuthi","Niveditha"]
usernames = ["anu14","nkund17"]
passwords = ["XXXX","YYYY"]

hashed_pwds = stauth.Hasher(passwords).generate()

file_path = Path(__file__).parent/"hashed_pwd.pkl"

with file_path.open("wb") as file:
    pickle.dump(hashed_pwds,file)