import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    database="SpaceXDB"
)
c = mydb.cursor()



def add_data_rocket(rocket_id, rocket_name, rocket_type, active,country, company, cost_per_launch):
    c.execute('INSERT INTO rockets (rocket_id, name, type, active,country, company, cost_per_launch) VALUES (%s,%s,%s,%s,%s,%s,%s)',
              (rocket_id, rocket_name, rocket_type, active,country, company, cost_per_launch))
    mydb.commit()

def add_data_payload(payload_id, name, type, reuse, manufacture, mass_kg,mass_lb,orbit,reference_system,regime):
    c.execute('INSERT INTO payloads (payload_id, name, type, reuse, manufacture, mass_kg, mass_lb, orbit, reference_system, regime) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);',
              (payload_id, name, type, reuse, manufacture, mass_kg,mass_lb,orbit,reference_system,regime))
    mydb.commit()

def add_data_launchpad(launchpad_id,name,full_name,status,locality,region,TimeZone , Latitude , Longitude):
    c.execute('INSERT INTO launchpads (launchpad_id,name,full_name,status,locality,region,TimeZone , Latitude , Longitude ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s);',
              (launchpad_id,name,full_name,status,locality,region,TimeZone , Latitude , Longitude ))
    mydb.commit()

def add_data_droneship(ship_id,home_port,name,type,roles,activity,mass_kg,mass_lb):
    c.execute('INSERT INTO droneship (ship_id,home_port,name,type,roles,activity,mass_kg,mass_lb) VALUES (%s,%s,%s,%s,%s,%s,%s,%s);',
              (ship_id,home_port,name,type,roles,activity,mass_kg,mass_lb))
    mydb.commit()

def add_data_admin(admin_id, name,password, access_level):
    c.execute('INSERT INTO administrators (admin_id, name,password, access_level) VALUES (%s,%s,%s,%s);',
              (admin_id, name,password, access_level))
    mydb.commit()

def add_data_launch(launchpad_id,rocket_id,name,status):
    c.execute('INSERT INTO launches (launchpad_id,rocket_id,name,status) VALUES (%s,%s,%s,%s);',
              (launchpad_id,rocket_id,name,status))
    mydb.commit()

def add_data_mission(my_datetime,selected_launchpad,selected_rocket,selected_payload,launch_id,name,launch_status):
    c.execute('INSERT INTO missions (date,name,rocket_id,launchpad_id,launch_id,payload_id,launch_status) VALUES (%s,%s,%s,%s,%s,%s,%s);',
              (my_datetime,name,selected_rocket,selected_launchpad,launch_id,selected_payload,launch_status))
    mydb.commit()

def view_max(orbit):
    c.execute('select orbit, check_max_mass("{}") from payloads where orbit="{}"  group by orbit '.format(orbit,orbit) )
    data = c.fetchall()
    return data

def procedure_call(date):
    c.callproc('launch_in_month',[date])
    x=[]
    for result in c.stored_results():
        mission= result.fetchall()
        for launch in mission:
            x.append(launch)
    return x


def view_all_data(table):
    temp='SELECT * FROM '+str(table)
    c.execute(temp)
    data = c.fetchall()
    return data


def view_only_names(table):
    temp='SELECT name FROM '+str(table)
    c.execute(temp)
    data = c.fetchall()
    return data

def get_details_rockets(id):
    c.execute('SELECT * FROM rockets WHERE rocket_id="{}"'.format(id))
    data = c.fetchall()
    return data

def get_details_payloads(id):
    c.execute('SELECT * FROM payloads WHERE payload_id="{}"'.format(id))
    data = c.fetchall()
    return data

def get_details_missions(id):
    c.execute('SELECT * FROM missions WHERE launch_id="{}"'.format(id))
    data = c.fetchall()
    return data

def get_details_administrators(id):
    c.execute('SELECT * FROM administrators WHERE admin_id="{}"'.format(id))
    data = c.fetchall()
    return data


def edit_details_rocket(new_rocket_name,new_cost_per_launch ,rocket_id):
    c.execute('UPDATE Rockets SET  Name=%s, cost_per_launch=%s WHERE rocket_id=%s', (new_rocket_name,new_cost_per_launch ,rocket_id))
    mydb.commit()


def edit_details_payload( new_payload_name, new_reuse, new_mass_kg,new_mass_lb,payload_id):
    c.execute('UPDATE Payloads SET  name=%s, reuse=%s , mass_kg=%s  , mass_lb=%s WHERE payload_id=%s', (new_payload_name, new_reuse, new_mass_kg,new_mass_lb,payload_id))
    mydb.commit()

def edit_details_mission( new_launch_status , launch_id):
    c.execute('UPDATE Missions SET  launch_status=%s WHERE launch_id=%s', (new_launch_status,launch_id))
    mydb.commit()

def edit_details_administrators( new_access_level, admin_id):
    c.execute('UPDATE administrators SET  access_level=%s  WHERE admin_id=%s', ( new_access_level, admin_id))
    mydb.commit() 




def delete_data_rocket(rocket_id):
    c.execute('DELETE FROM rockets WHERE rocket_id="{}"'.format(rocket_id))
    mydb.commit()


def delete_data_payload(payload_id):
    c.execute('DELETE FROM payloads WHERE payload_id="{}"'.format(payload_id))
    mydb.commit()

def delete_data_mission(launch_id):
    c.execute('DELETE FROM missions WHERE launch_id="{}"'.format(launch_id))
    mydb.commit()

def delete_data_droneship(ship_id):
    c.execute('DELETE FROM droneship WHERE ship_id="{}"'.format(ship_id))
    mydb.commit()

def delete_data_admin(admin_id):
    c.execute('DELETE FROM administrators WHERE admin_id="{}"'.format(admin_id))
    mydb.commit()





