import pandas as pd
import streamlit as st
from database import view_all_data, view_only_names, delete_data_rocket,delete_data_mission,delete_data_payload,delete_data_droneship,delete_data_admin


def delete_rocket():
    result = view_all_data('rockets')
    df = pd.DataFrame(result, columns=['rocket_id', 'name', 'type', 'active', 'country','company', 'cost_per_launch'])
    with st.expander("Current data"):
        st.dataframe(df)

    list_of_rockets = [i for i in df['rocket_id']]
    selected_rocket = st.selectbox("choose the rocket id of rocket to Delete", list_of_rockets)
    st.warning("Do you want to delete ::{}".format(selected_rocket))
    if st.button("Delete rocket"):
        delete_data_rocket(selected_rocket)
        st.success("Rocket has been deleted successfully")
    new_result = view_all_data('rockets')
    df2 = pd.DataFrame(new_result, columns=['rocket_id', 'name', 'type', 'active','country', 'company', 'cost_per_launch'])
    with st.expander("Updated data"):
        st.dataframe(df2)

def delete_payload():
    result = view_all_data('payloads')
    df = pd.DataFrame(result, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
    with st.expander("Current data"):
        st.dataframe(df)

    list_of_payload = [i for i in df['payload_id']]
    selected_payload = st.selectbox("choose the payload id of the payload to Delete", list_of_payload)
    st.warning('Do you want to delete :"{}"'.format(selected_payload))
    if st.button("Delete payload"):
        delete_data_payload(selected_payload)
        st.success("Payload has been deleted successfully")
    new_result = view_all_data('payloads')
    df2 = pd.DataFrame(new_result, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
    with st.expander("Updated data"):
        st.dataframe(df2)


def delete_mission():
    result = view_all_data('missions')
    df = pd.DataFrame(result, columns=['date', 'name', 'rocket_id','launchpad_id', 'launch_id', 'payload_id','launch_status'])
    with st.expander("Current data"):
        st.dataframe(df)

    list_of_missions = [i for i in df['launch_id']]
    selected_mission = st.selectbox("Choose the launch id of the mission to Delete", list_of_missions)
    st.warning('Do you want to delete :"{}"'.format(selected_mission))
    if st.button("Delete mission"):
        delete_data_mission(selected_mission)
        st.success("Mission has been deleted successfully")
    new_result = view_all_data('missions')
    df2 = pd.DataFrame(new_result, columns=['date', 'name', 'rocket_id','launchpad_id', 'launch_id', 'payload_id','launch_status'])
    with st.expander("Updated data"):
        st.dataframe(df2)



def delete_droneship():
    result = view_all_data('droneship')
    df = pd.DataFrame(result, columns=['ship_id','home_port','name','type','roles','activity','mass_kg','mass_lb'])
    with st.expander("Current data"):
        st.dataframe(df)

    list_of_drones = [i for i in df['ship_id']]
    selected_drone = st.selectbox(" Choose the ship_id of Droneship to Delete", list_of_drones)
    st.warning('Do you want to delete :"{}"'.format(selected_drone))
    if st.button("Delete Droneship"):
        delete_data_droneship(selected_drone)
        st.success("Droneship has been deleted successfully")
    new_result = view_all_data('droneship')
    df2 = pd.DataFrame(new_result, columns=['ship_id','home_port','name','type','roles','activity','mass_kg','mass_lb'])
    with st.expander("Updated data"):
        st.dataframe(df2)

def delete_admin():
    result = view_all_data('administrators')
    df = pd.DataFrame(result, columns=['admin_id', 'name', 'password', 'access_level'])
    with st.expander("Current data"):
        st.dataframe(df)

    list_of_admins = [i for i in df['admin_id']]
    selected_admin = st.selectbox("Choose the admin id of the Admin to Delete", list_of_admins)
    st.warning('Do you want to delete :"{}"'.format(selected_admin))
    if st.button("Delete Admin"):
        delete_data_admin(selected_admin)
        st.success("Administrator has been deleted successfully")
    new_result = view_all_data('administrators')
    df2 = pd.DataFrame(new_result, columns=['admin_id', 'name', 'password', 'access_level'])
    with st.expander("Updated data"):
        st.dataframe(df2)


