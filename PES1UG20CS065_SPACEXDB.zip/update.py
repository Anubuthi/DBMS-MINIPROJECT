import datetime
import pandas as pd
import numpy as np
import streamlit as st
from database import view_all_data, view_only_names,get_details_rockets,get_details_payloads,get_details_missions,get_details_administrators, edit_details_rocket, edit_details_payload, edit_details_mission, edit_details_administrators


def update_rocket():
    result = view_all_data('rockets')
    # st.write(result)
    df = pd.DataFrame(result, columns=['rocket_id', 'name', 'type', 'active','country', 'company', 'cost_per_launch'])
    with st.expander("Current Rockets"):
        st.dataframe(df)
    list_of_rockets = [i for i in df['rocket_id']]
    selected_rocket = st.selectbox("choose the rocket id of rocket to update", list_of_rockets)
    selected_result = get_details_rockets(selected_rocket)
    
    rocket_id = selected_result[0][0]
    name = selected_result[0][1]
    cost_per_launch = selected_result[0][6]


    col1, col2 = st.columns(2)
    with col1:
        new_name = st.text_input("Name:", name)
    with col2:
        new_cost_per_launch = st.text_input("Cost Per Launch:", cost_per_launch)


    if st.button("Update ROCKET"):
        edit_details_rocket( new_name, new_cost_per_launch,rocket_id)
        st.success("Successfully updated:: {} to ::{}".format(name, new_name))

    result2 = view_all_data('rockets')
    df2 = pd.DataFrame(result2, columns=['rocket_id', 'name', 'type', 'active','country', 'company', 'cost_per_launch'])
    with st.expander("Updated data"):
        st.dataframe(df2)


def update_payload():
    result = view_all_data('payloads')
    # st.write(result)
    df = pd.DataFrame(result, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
    with st.expander("Current payloads"):
        st.dataframe(df)
    list_of_p = [i for i in df['payload_id']]
    selected_p = st.selectbox("choose the payload id of payload to update", list_of_p)
    selected_result = get_details_payloads(selected_p)

    # st.write(selected_result)
  
    payload_id = selected_result[0][0]
    name = selected_result[0][1]
    reuse = selected_result[0][3]
    mass_kg = selected_result[0][5]
    mass_lb=selected_result[0][6]



        

    col1, col2 = st.columns(2)
    with col1:
        new_payload_name = st.text_input("Name:", name)
        new_reuse = st.selectbox(reuse, ["true","false"])
    with col2:
        new_mass_kg = st.text_input("Mass in Kg:", mass_kg)
        new_mass_lb=st.text_input("Mass in lb:", mass_lb)

    if st.button("Update Payload"):
        
        edit_details_payload(new_payload_name, new_reuse, new_mass_kg,new_mass_lb,payload_id)
        st.success("Successfully updated:: {} to ::{}".format(name, new_payload_name))

    result2 = view_all_data('payloads')
    df2 = pd.DataFrame(result2, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
    with st.expander("Updated data"):
        st.dataframe(df2)

def update_mission():
    result = view_all_data('missions')
    # st.write(result)
    df = pd.DataFrame(result, columns=['date', 'name', 'rocket_id','launchpad_id', 'launch_id', 'payload_id','launch_status'])
    with st.expander("Current missions"):
        st.dataframe(df)
    list_of_missions =[i for i in df['launch_id']]
    selected_mission = st.selectbox("Missions to Edit", list_of_missions)
    selected_result = get_details_missions(selected_mission)

    date = selected_result[0][0]
    name = selected_result[0][1]
    rocket_id = selected_result[0][2]
    launchpad_id = selected_result[0][3]
    launch_id = selected_result[0][4]
    payload_id = selected_result[0][5]
    launch_status=selected_result[0][6]

        
    st.subheader("Launch_status")
    new_launch_status = st.selectbox("True", ["False","True"])


    if st.button("Update missions"):
        edit_details_mission(new_launch_status , launch_id)
        st.success("Successfully updated:: {} to ::{}".format(launch_status, new_launch_status))

    result2 = view_all_data('missions')
    df2 = pd.DataFrame(result2, columns=['date', 'name', 'rocket_id','launchpad_id', 'launch_id', 'payload_id','launch_status'])
    with st.expander("Updated data"):
        st.dataframe(df2)





def update_admin():
    result = view_all_data('administrators')
    # st.write(result)
    df = pd.DataFrame(result, columns=['admin_id', 'name', 'password', 'access_level'])
    with st.expander("Current admins"):
        st.dataframe(df)
    list_of_admins =[i for i in df['admin_id']]
    selected_admin = st.selectbox("admin to Edit", list_of_admins)
    selected_result = get_details_administrators(selected_admin)
    
    admin_id = selected_result[0][0]
    name = selected_result[0][1]
    password = selected_result[0][2]
    access_level = selected_result[0][3]

    st.write("Change the access level of administrator:")
    new_access_level = st.selectbox(access_level,["Root","standard"])

    if st.button("Update Admin"):
        edit_details_administrators( new_access_level, admin_id)
        st.success("Successfully updated")

    result2 = view_all_data('administrators')
    df2 = pd.DataFrame(result2, columns=['admin_id', 'name', 'password', 'access_level'])
    with st.expander("Updated data"):
        st.dataframe(df2)