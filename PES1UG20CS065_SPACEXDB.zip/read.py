import pandas as pd
import streamlit as st
import plotly.express as px
from database import view_all_data ,view_max,procedure_call

def read_rocket():
    temp='rockets'
    result = view_all_data(temp)
    # st.write(result)
    df = pd.DataFrame(result, columns=['rocket_id', 'name', 'type', 'active','country', 'company', 'cost_per_launch'])
    with st.expander("View all Rockets"):
        st.dataframe(df)
    with st.expander("View names of the Rockets"):
        st.dataframe(df['name'])
    with st.expander("Rocket Details"): 
        active_df = df['active'].value_counts().to_frame()
        active_df = active_df.reset_index()
        st.dataframe(active_df)
        p1 = px.pie(active_df, names='index')
        st.plotly_chart(p1)


def read_payload():
    result = view_all_data('payloads')
    # st.write(result)
    df = pd.DataFrame(result, columns=['payload_id', 'name', 'payload_type', 'reuse', 'manufacture', 'mass_kg','mass_lb','orbit','reference_system','regime'])
    with st.expander("View all payloads"):
        st.dataframe(df)
    with st.expander("View names of the Payloads"):
        st.dataframe(df['name'])
    
    with st.subheader("View max weights of payloads in each orbit"):
        orbit_df = df['orbit']
        distinct_orbit=list(set(orbit_df))
        selected_orbit = st.selectbox("View max weights", distinct_orbit)
        
        
    data=view_max(selected_orbit)
    data=pd.DataFrame(data,columns=['orbit','max_weight'])
    st.dataframe(data)


    with st.expander("Payload Details"):
        refernce_system_df = df['reference_system'].value_counts().to_frame()
        refernce_system_df = refernce_system_df.reset_index()
        st.dataframe(refernce_system_df)
        p1 = px.pie(refernce_system_df, names='index')
        st.plotly_chart(p1)

        regime_df = df['regime'].value_counts().to_frame()
        regime_df = regime_df.reset_index()
        st.dataframe(regime_df)
        p2 = px.pie(regime_df, names='index')
        st.plotly_chart(p2)

        orbit_df = df['orbit'].value_counts().to_frame()
        orbit_df = orbit_df.reset_index()
        st.dataframe(orbit_df)
        p3 = px.pie(orbit_df, names='index')
        st.plotly_chart(p3)






def read_mission():
    result = view_all_data('missions')
    # st.write(result)
    df = pd.DataFrame(result, columns=['date', 'name', 'rocket_id','launchpad_id', 'launch_id', 'payload_id','launch_status'])
    with st.expander("View all Missions"):
        st.dataframe(df)
    with st.expander("View names of the Missions"):
        st.dataframe(df['name'])
    with st.expander("Mission Details"):
        ls_df = df['launch_status'].value_counts().to_frame()
        ls_df = ls_df.reset_index()
        st.dataframe(ls_df)
        p1 = px.pie(ls_df, names='index', values='launch_status')
        st.plotly_chart(p1)

    st.subheader("Missions in a given year and month")
    date=st.text_input("Enter year and month as yyyy-mm")
    table=procedure_call(date)
    df=pd.DataFrame(table,columns=['launchpad_name','rocket_name','payload_name','launch_id','mission_name','launch_status'])
    st.dataframe(df)
        


def read_launchpad():
    result = view_all_data('launchpads')
    # st.write(result)
    df = pd.DataFrame(result, columns=['launchpad_id','name','full_name','status','locality','region','TimeZone' , 'Latitude' , 'Longitude'])
    with st.expander("View all LaunchPads"):
        st.dataframe(df)
    with st.expander("View names of the Launch pads"):
        st.dataframe(df['full_name'])
    with st.expander("Launchpad Details"):
        s_df = df['status'].value_counts().to_frame()
        s_df = s_df.reset_index()
        st.dataframe(s_df)
        p1 = px.pie(s_df, names='index', values='status')
        st.plotly_chart(p1)

        r_df = df['region'].value_counts().to_frame()
        r_df = r_df.reset_index()
        st.dataframe(r_df)
        p2 = px.pie(r_df, names='index', values='region')
        st.plotly_chart(p2)




def read_droneship():
    result = view_all_data('droneship')
    # st.write(result)
    df = pd.DataFrame(result, columns=['ship_id','home_port','name','type','roles','activity','mass_kg','mass_lb'])
    with st.expander("View all Drone ships"):
        st.dataframe(df)
    with st.expander("View names of the Drones"):
        st.dataframe(df['name'])
    with st.expander("Drone Ship Details"):
        r_df = df['roles'].value_counts().to_frame()
        r_df = r_df.reset_index()
        st.dataframe(r_df)
        p1 = px.pie(r_df, names='index')
        st.plotly_chart(p1)




def read_admin():
    result = view_all_data('administrators')
    # st.write(result)
    df = pd.DataFrame(result, columns=['admin_id', 'name', 'password', 'access_level'])
    with st.expander("View all Admins"):
        st.dataframe(df)
    with st.expander("View names of the Amins"):
        st.dataframe(df['name'])
    with st.expander("Admins Details"):
        ad_df = df['access_level'].value_counts().to_frame()
        ad_df = ad_df.reset_index()
        st.dataframe(ad_df)
        p1 = px.pie(ad_df, names='index', values='access_level')
        st.plotly_chart(p1)


def read_launch():
    result=view_all_data('launches')
    df=pd.DataFrame(result,columns=['launchpad_id','rocket_id','name','status'])
    with st.expander("View all Launches"):
        st.dataframe(df)
    with st.expander("View names of the Launches"):
        st.dataframe(df['name'])
    